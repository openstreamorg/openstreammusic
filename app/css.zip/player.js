const playPauseBtn = document.querySelector("#play-pause-btn");
const songName = document.querySelector("#song-name");
const artistName = document.querySelector("#artist-name");
const albumCover = document.querySelector("#album-cover");
const volumeSlider = document.querySelector("#volume-slider");
const audioPlayer = document.querySelector("#audio-player");

let isPlaying = false;

playPauseBtn.addEventListener("click", () => {
  if (isPlaying) {
    audioPlayer.pause();
    playPauseBtn.innerHTML = '<i class="material-icons">play_arrow</i>';
    isPlaying = false;
  } else {
    audioPlayer.play();
    playPauseBtn.innerHTML = '<i class="material-icons">pause</i>';
    isPlaying = true;
  }
});

audioPlayer.addEventListener("timeupdate", () => {
  const progressBar = document.querySelector("#progress-bar");
  const currentTime = document.querySelector("#current-time");

  let duration = audioPlayer.duration;
  let currentTimeValue = audioPlayer.currentTime;
  let progress = (currentTimeValue / duration) * 100;

  progressBar.style.width = progress + "%";
  currentTime.textContent = formatTime(currentTimeValue);
});

volumeSlider.addEventListener("input", () => {
  audioPlayer.volume = volumeSlider.value / 100;
});

function formatTime(seconds) {
  let min = Math.floor(seconds / 60);
  let sec = Math.floor(seconds % 60);

  if (sec < 10) {
    sec = "0" + sec;
  }

  return min + ":" + sec;
}
